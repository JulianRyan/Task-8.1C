package com.example.musicplayer;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.SeekBar;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.io.IOException;

public class PlayerActivity extends YouTubeBaseActivity {
    public static final String API_KEY = "AIzaSyCns2WP0ij30HnOxh8F8Jc_rh7U6l473qs";

    YouTubePlayerView youTubePlayerView;
    YouTubePlayer.OnInitializedListener videoOnInitializedListener;
    String url;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        youTubePlayerView = findViewById(R.id.videoVideoView);
        url = getIntent().getStringExtra("URL");
        videoOnInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
                youTubePlayer.loadVideo(url);
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                Log.d("TAG", "onInitializationFailure: "+youTubeInitializationResult.toString());
                Toast.makeText(getApplicationContext(), "Error"+youTubeInitializationResult.toString(), Toast.LENGTH_SHORT).show();
            }
        };
        youTubePlayerView.initialize(API_KEY, videoOnInitializedListener);
    }

}